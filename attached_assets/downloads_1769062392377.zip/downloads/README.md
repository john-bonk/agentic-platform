# Hyperprompt File Extraction - Audit Agent Intelligence System

This folder contains all the core files needed to replicate the Audit Agent intelligence architecture, Settings system, and Home dashboard components in another Replit instance.

## Files Included

### 1. Data Layer
- **schema.ts** - Complete Zod schemas for Controls, Tasks, Reports, Users, Audits, Evidence, Notifications, Messages, and Dashboard Metrics

### 2. Theme System
- **use-theme.tsx** - Theme provider hook with localStorage persistence and system preference detection

### 3. Settings System
- **settings-panel.tsx** - Slide-out settings sheet with dark mode toggle, layout editing, refresh intervals, agent configuration, and task status filters
- **settings.tsx** - Full settings page with profile, appearance, notifications, and security sections

### 4. Audit Agent Intelligence Architecture (Three-Tier System)

#### Tier 1: Entry Point
- **audit-agent.tsx** - Command input card with prompt library, history dialog, report generation detection, and AI panel trigger

#### Tier 2: Chat Drawer
- **ai-assistant-panel.tsx** - Slide-out chat panel with simulated AI responses, resource cards (Tasks, Reports, Controls), typing indicators, and keyboard shortcuts

#### Tier 3: In-Context Report Editor
- **report-agent.tsx** (~1136 lines) - Sophisticated NLP-powered report modification agent with:
  - Natural language section management (add, edit, remove)
  - Chart generation (bar, pie, line) with smart data detection
  - Control/user/metrics search capabilities
  - Partial content removal within sections
  - Quick actions and suggestion prompts

### 5. Home Dashboard
- **home.tsx** - Main dashboard page integrating AuditAgent, AIAssistantPanel, and tab navigation

### 6. Backend API
- **routes.ts** - Express routes including:
  - Report generation with LLM integration pattern
  - RSS feed fetching for industry news
  - CRUD operations for controls, audits, tasks
  - Shared link management
  - Twilio SMS integration

---

## Implementation Order

### Phase 1: Foundation
1. Copy `schema.ts` to `shared/schema.ts`
2. Copy `use-theme.tsx` to `client/src/hooks/use-theme.tsx`
3. Wrap your App with `<ThemeProvider>`

### Phase 2: Settings
1. Copy `settings-panel.tsx` to `client/src/components/settings-panel.tsx`
2. Copy `settings.tsx` to `client/src/pages/settings.tsx`
3. Add settings route to your router

### Phase 3: Audit Agent System
1. Copy `audit-agent.tsx` to `client/src/components/home/audit-agent.tsx`
2. Copy `ai-assistant-panel.tsx` to `client/src/components/home/ai-assistant-panel.tsx`
3. Copy `report-agent.tsx` to `client/src/components/report-agent.tsx`

### Phase 4: Dashboard Integration
1. Copy `home.tsx` to `client/src/pages/home.tsx`
2. Ensure all component imports are correct

### Phase 5: Backend
1. Copy relevant route handlers from `routes.ts`
2. Set up storage interface matching the schema types

---

## Key Dependencies

```json
{
  "lucide-react": "icons",
  "@tanstack/react-query": "data fetching",
  "wouter": "routing",
  "zod": "validation",
  "rss-parser": "news feeds (backend)"
}
```

## Required Shadcn Components
- Card, Button, Input, Badge
- Dialog, Sheet, Tabs
- Select, Switch, Slider, Textarea
- Avatar, Separator, ScrollArea
- Tooltip

---

## Test IDs for E2E Testing

### Audit Agent
- `input-audit-agent` - Main query input
- `button-submit-query` - Submit button
- `button-view-history` - History dialog trigger
- `prompt-library-{i}` - Prompt library items
- `history-item-{i}` - History items

### AI Panel
- `ai-panel-overlay` - Background overlay
- `ai-assistant-panel` - Panel container
- `button-close-panel` - Close button
- `input-panel-prompt` - Chat input
- `button-send-message` - Send button

### Report Agent
- `button-expand-agent` - FAB to open
- `button-minimize-agent` - Collapse button

### Settings
- `button-settings` - Settings trigger
- `switch-dark-mode` - Dark mode toggle
- `switch-layout-edit` - Layout editing toggle
- `slider-refresh-interval` - Refresh interval
- `switch-agent-enabled` - Agent toggle
- `select-agent-tone` - Response tone selector
